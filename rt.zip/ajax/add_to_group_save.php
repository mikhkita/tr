<li>Скилл-группа 1 <a href="#" class="icon-close b-remove-list"></a><input type="hidden" name="groups[]" value="1"></li>
<li>Скилл-группа 5 <a href="#" class="icon-close b-remove-list"></a><input type="hidden" name="groups[]" value="5"></li>
<li>Скилл-группа 6 <a href="#" class="icon-close b-remove-list"></a><input type="hidden" name="groups[]" value="6"></li>
<li>Скилл-группа 3 <a href="#" class="icon-close b-remove-list"></a><input type="hidden" name="groups[]" value="3"></li>
<li>Скилл-группа 4 <a href="#" class="icon-close b-remove-list"></a><input type="hidden" name="groups[]" value="4"></li>