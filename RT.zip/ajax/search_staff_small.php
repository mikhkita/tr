<? if( $_GET["q"] == "" ): ?>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E94B35;">
			<img src="i/avatar-1.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Константин Константинопальский</a>
		<div class="b-staff-item__post">Филиал 1, старший инженер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E37828;">
			<img src="i/avatar-2.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Василий Кошкин</a>
		<div class="b-staff-item__post">Филиал 5, бухгалтер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #00BD9C;">
			<img src="i/avatar-3.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Наталья Смирнова</a>
		<div class="b-staff-item__post">Филиал 3, секретарь</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E94B35;">
			<img src="i/avatar-1.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Константин Константинопальский</a>
		<div class="b-staff-item__post">Филиал 1, старший инженер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E37828;">
			<img src="i/avatar-2.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Василий Кошкин</a>
		<div class="b-staff-item__post">Филиал 5, бухгалтер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #00BD9C;">
			<img src="i/avatar-3.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Наталья Смирнова</a>
		<div class="b-staff-item__post">Филиал 3, секретарь</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E94B35;">
			<img src="i/avatar-1.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Константин Константинопальский</a>
		<div class="b-staff-item__post">Филиал 1, старший инженер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E37828;">
			<img src="i/avatar-2.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Василий Кошкин</a>
		<div class="b-staff-item__post">Филиал 5, бухгалтер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #00BD9C;">
			<img src="i/avatar-3.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Наталья Смирнова</a>
		<div class="b-staff-item__post">Филиал 3, секретарь</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E94B35;">
			<img src="i/avatar-1.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Константин Константинопальский</a>
		<div class="b-staff-item__post">Филиал 1, старший инженер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E37828;">
			<img src="i/avatar-2.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Василий Кошкин</a>
		<div class="b-staff-item__post">Филиал 5, бухгалтер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #00BD9C;">
			<img src="i/avatar-3.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Наталья Смирнова</a>
		<div class="b-staff-item__post">Филиал 3, секретарь</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E94B35;">
			<img src="i/avatar-1.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Константин Константинопальский</a>
		<div class="b-staff-item__post">Филиал 1, старший инженер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E37828;">
			<img src="i/avatar-2.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Василий Кошкин</a>
		<div class="b-staff-item__post">Филиал 5, бухгалтер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #00BD9C;">
			<img src="i/avatar-3.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Наталья Смирнова</a>
		<div class="b-staff-item__post">Филиал 3, секретарь</div>
	</div>
</div>	
<? elseif(mb_strlen($_GET["q"], "UTF-8") < 6): ?>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E94B35;">
			<img src="i/avatar-1.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Константин Константинопальский</a>
		<div class="b-staff-item__post">Филиал 1, старший инженер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #E37828;">
			<img src="i/avatar-2.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Василий Кошкин</a>
		<div class="b-staff-item__post">Филиал 5, бухгалтер</div>
	</div>
</div>
<div class="b-staff-item clearfix">
	<div class="b-staff-item__image">
		<a href="ajax/view_man.php" class="b-avatar ajax-popup" style="background: #00BD9C;">
			<img src="i/avatar-3.jpg" alt="">
		</a>
	</div>
	<div class="b-staff-item__online">Online</div>
	<div class="b-staff-item__text">
		<a href="ajax/view_man.php" class="b-staff-item__name ajax-popup">Наталья Смирнова</a>
		<div class="b-staff-item__post">Филиал 3, секретарь</div>
	</div>
</div>
<? else: ?>
	<h3>По вашему запросу ничего не найдено</h3>
<? endif; ?>