<div class="b-popup b-big-popup b-view-man">
	<h2>Информация о сотруднике</h2>
	<div class="b-detail b-big-detail b-man-detail clearfix">
		<div class="b-detail-left">
			<img src="i/avatar-2.jpg" alt="">
			<ul class="b-link-list">
				<li><a href="ajax/add_to_group_form.php?id=1" class="ajax-popup">Добавить в список</a></li>
				<li><a href="ajax/update_man_form.php?id=1" class="ajax-popup">Редактировать профиль</a></li>
			</ul>
		</div>
		<div class="b-detail-right">
			<h3>Константин Константинович Константинопальский</h3>
			<div class="b-detail-online">Online</div>
			<div class="clearfix">
				<div class="b-man-left">
					<ul class="b-link-list">
						<li><b>Филиал:</b> филиал 3 (+1 час)</li>
						<li><b>Должность:</b> Главный маркетолог</li>
						<li><b>Отдел:</b> Маркетинговый отдел</li>
						<li><b>E-mail:</b> kkk@mail.ru</li>
						<li><b>Рабочий телефон:</b> +7 (000) 000-00-00</li>
						<li><b>Личный телефон:</b> +7 (000) 000-00-00</li>
					</ul>
					<div class="b-progressbar-link">
						<div class="b-progressbar-stat"><b>75%</b> заявок обработано</div>
						<div class="b-progressbar-cont without-icon without-percent">
							<div class="b-line-progressbar orange" data-percent="75"></div>
						</div>
					</div>
					<div class="b-progressbar-link">
						<div class="b-progressbar-stat"><b>90%</b> звонков совершено</div>
						<div class="b-progressbar-cont without-icon without-percent">
							<div class="b-line-progressbar blue" data-percent="90"></div>
						</div>
					</div>	
					<div class="b-systems">
						<div class="b-system">
							<span class="icon-cross"></span>Система с очень длинным названием
						</div>
						<div class="b-system">
							<span class="icon-check"></span>Система x
						</div>
						<div class="b-system">
							<span class="icon-cross"></span>Система для счастливых сотрудников
						</div>
					</div>
				</div>
				<div class="b-man-right">
					<ul class="b-link-list">
						<li><b>Скилл-группы:</b></li>
						<li>Скилл-группа 1</li>
						<li>Скилл-группа 5</li>
						<li>Скилл-группа 6</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>